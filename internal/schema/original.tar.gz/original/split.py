#!/usr/bin/python
import os

def execute(go_code):

    go_code += '\n'
    # Split the code into individual structs
    structs = go_code.split("}\n\n")
    structs = [s + "}\n" for s in structs if s]

    # Create a directory to store the structs if it doesn't exist
    output_dir = "../"

    # Write each struct to its own file
    for struct in structs:
        # Extract the struct name
        lines = struct.splitlines()

        for line in lines:
            if line.strip().startswith("type"):
                struct_name = line.split()[1]
                break

        # Ensure there is a newline at the end of the struct
        if not struct.endswith("\n"):
            struct += "\n"

        struct = """import (
	        "encoding/xml"
        )\n""" + struct
        struct = "package schema\n" + struct

        # Write the struct to its own file
        file_path = os.path.join(output_dir, f"{struct_name}.go")
        with open(file_path, "w") as f:
            f.write(struct)

def start():
    for entry in os.listdir("."):
        if not entry.endswith(".txt"):
            continue

        with open(entry, 'r', encoding='utf-8') as file:
            content = file.read()
            print(entry)
            execute(content)

if __name__ == "__main__":
    start()

